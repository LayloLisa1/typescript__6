import express from 'express';
import dotenv from 'dotenv';
import userRouter from './controllers/user.controller';
import artistRouter from './controllers/artist.controller';
import trackRouter from './controllers/track.controller';
import albumRouter from './controllers/album.controller';
import favoritesRouter from './controllers/favorites.controller';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());

app.use('/user', userRouter);
app.use('/artist', artistRouter);
app.use('/track', trackRouter);
app.use('/album', albumRouter);
app.use('/favs', favoritesRouter);

export default app;
