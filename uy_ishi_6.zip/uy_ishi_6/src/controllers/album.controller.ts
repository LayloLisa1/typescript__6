import { Request, Response, Router } from 'express';
import { AlbumService } from '../services/album.service';
import { validateUUID } from '../utils/validateUUID';

const albumService = new AlbumService();
const router = Router();

router.get('/', (req: Request, res: Response) => {
  const albums = albumService.findAll();
  res.status(200).json(albums);
});

router.get('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const album = albumService.findOne(id);
  if (!album) {
    return res.status(404).json({ message: 'Album not found' });
  }
  res.status(200).json(album);
});

router.post('/', (req: Request, res: Response) => {
  const { name, year, artistId } = req.body;
  if (!name || typeof year !== 'number') {
    return res.status(400).json({ message: 'Name and year are required' });
  }
  const newAlbum = albumService.create(name, year, artistId);
  res.status(201).json(newAlbum);
});

router.put('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const { name, year, artistId } = req.body;
  if (!name || typeof year !== 'number') {
    return res.status(400).json({ message: 'Name and year are required' });
  }
  const updatedAlbum = albumService.update(id, name, year, artistId);
  if (!updatedAlbum) {
    return res.status(404).json({ message: 'Album not found' });
  }
  res.status(200).json(updatedAlbum);
});

router.delete('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const deleted = albumService.delete(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Album not found' });
  }
  res.status(204).send();
});

export default router;
