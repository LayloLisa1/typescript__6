import { Request, Response, Router } from 'express';
import { ArtistService } from '../services/artist.service';
import { validateUUID } from '../utils/validateUUID';

const artistService = new ArtistService();
const router = Router();

router.get('/', (req: Request, res: Response) => {
  const artists = artistService.findAll();
  res.status(200).json(artists);
});

router.get('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const artist = artistService.findOne(id);
  if (!artist) {
    return res.status(404).json({ message: 'Artist not found' });
  }
  res.status(200).json(artist);
});

router.post('/', (req: Request, res: Response) => {
  const { name, grammy } = req.body;
  if (!name || typeof grammy !== 'boolean') {
    return res.status(400).json({ message: 'Name and Grammy status are required' });
  }
  const newArtist = artistService.create(name, grammy);
  res.status(201).json(newArtist);
});

router.put('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const { name, grammy } = req.body;
  if (!name || typeof grammy !== 'boolean') {
    return res.status(400).json({ message: 'Name and Grammy status are required' });
  }
  const updatedArtist = artistService.update(id, name, grammy);
  if (!updatedArtist) {
    return res.status(404).json({ message: 'Artist not found' });
  }
  res.status(200).json(updatedArtist);
});

router.delete('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const deleted = artistService.delete(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Artist not found' });
  }
  res.status(204).send();
});

export default router;
