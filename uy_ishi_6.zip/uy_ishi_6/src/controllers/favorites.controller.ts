import { Request, Response, Router } from 'express';
import { FavoritesService } from '../services/favorites.service';
import { validateUUID } from '../utils/validateUUID';

const favoritesService = new FavoritesService();
const router = Router();

router.get('/', (req: Request, res: Response) => {
  const favorites = favoritesService.findAll();
  res.status(200).json(favorites);
});

router.post('/track/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const added = favoritesService.addTrack(id);
  if (!added) {
    return res.status(422).json({ message: 'Track not found' });
  }
  res.status(201).send();
});

router.delete('/track/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const removed = favoritesService.removeTrack(id);
  if (!removed) {
    return res.status(404).json({ message: 'Track not in favorites' });
  }
  res.status(204).send();
});

router.post('/album/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const added = favoritesService.addAlbum(id);
  if (!added) {
    return res.status(422).json({ message: 'Album not found' });
  }
  res.status(201).send();
});

router.delete('/album/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const removed = favoritesService.removeAlbum(id);
  if (!removed) {
    return res.status(404).json({ message: 'Album not in favorites' });
  }
  res.status(204).send();
});

router.post('/artist/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const added = favoritesService.addArtist(id);
  if (!added) {
    return res.status(422).json({ message: 'Artist not found' });
  }
  res.status(201).send();
});

router.delete('/artist/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const removed = favoritesService.removeArtist(id);
  if (!removed) {
    return res.status(404).json({ message: 'Artist not in favorites' });
  }
  res.status(204).send();
});

export default router;
