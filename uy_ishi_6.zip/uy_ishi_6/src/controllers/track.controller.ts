import { Request, Response, Router } from 'express';
import { TrackService } from '../services/track.service';
import { validateUUID } from '../utils/validateUUID';

const trackService = new TrackService();
const router = Router();

router.get('/', (req: Request, res: Response) => {
  const tracks = trackService.findAll();
  res.status(200).json(tracks);
});

router.get('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const track = trackService.findOne(id);
  if (!track) {
    return res.status(404).json({ message: 'Track not found' });
  }
  res.status(200).json(track);
});

router.post('/', (req: Request, res: Response) => {
  const { name, artistId, albumId, duration } = req.body;
  if (!name || typeof duration !== 'number') {
    return res.status(400).json({ message: 'Name and duration are required' });
  }
  const newTrack = trackService.create(name, artistId, albumId, duration);
  res.status(201).json(newTrack);
});

router.put('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const { name, artistId, albumId, duration } = req.body;
  if (!name || typeof duration !== 'number') {
    return res.status(400).json({ message: 'Name and duration are required' });
  }
  const updatedTrack = trackService.update(id, name, artistId, albumId, duration);
  if (!updatedTrack) {
    return res.status(404).json({ message: 'Track not found' });
  }
  res.status(200).json(updatedTrack);
});

router.delete('/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  if (!validateUUID(id)) {
    return res.status(400).json({ message: 'Invalid UUID' });
  }
  const deleted = trackService.delete(id);
  if (!deleted) {
    return res.status(404).json({ message: 'Track not found' });
  }
  res.status(204).send();
});

export default router;
