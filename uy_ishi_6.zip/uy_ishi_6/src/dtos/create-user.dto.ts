export interface CreateUserDto {
    login: string;
    password: string;
  }
  