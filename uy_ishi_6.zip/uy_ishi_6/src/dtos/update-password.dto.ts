export interface UpdatePasswordDto {
    oldPassword: string;
    newPassword: string;
  }
  