import { Album } from '../interfaces/album.interface';
import { v4 as uuidv4 } from 'uuid';

let albums: Album[] = [];

export class AlbumService {
  findAll(): Album[] {
    return albums;
  }

  findOne(id: string): Album | undefined {
    return albums.find(album => album.id === id);
  }

  create(name: string, year: number, artistId: string | null): Album {
    const newAlbum: Album = {
      id: uuidv4(),
      name,
      year,
      artistId,
    };
    albums.push(newAlbum);
    return newAlbum;
  }

  update(id: string, name: string, year: number, artistId: string | null): Album | undefined {
    const album = this.findOne(id);
    if (album) {
      album.name = name;
      album.year = year;
      album.artistId = artistId;
      return album;
    }
    return undefined;
  }

  delete(id: string): boolean {
    const albumIndex = albums.findIndex(album => album.id === id);
    if (albumIndex !== -1) {
      albums.splice(albumIndex, 1);
      return true;
    }
    return false;
  }
}
