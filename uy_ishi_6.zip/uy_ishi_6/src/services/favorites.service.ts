import { Favorites } from '../interfaces/favorites.interface';
import { ArtistService } from './artist.service';
import { AlbumService } from './album.service';
import { TrackService } from './track.service';

let favorites: Favorites = {
  artists: [],
  albums: [],
  tracks: [],
};

export class FavoritesService {
  private artistService: ArtistService;
  private albumService: AlbumService;
  private trackService: TrackService;

  constructor() {
    this.artistService = new ArtistService();
    this.albumService = new AlbumService();
    this.trackService = new TrackService();
  }

  findAll(): Favorites {
    return favorites;
  }

  addTrack(id: string): boolean {
    if (this.trackService.findOne(id)) {
      favorites.tracks.push(id);
      return true;
    }
    return false;
  }

  removeTrack(id: string): boolean {
    const index = favorites.tracks.indexOf(id);
    if (index !== -1) {
      favorites.tracks.splice(index, 1);
      return true;
    }
    return false;
  }

  addAlbum(id: string): boolean {
    if (this.albumService.findOne(id)) {
      favorites.albums.push(id);
      return true;
    }
    return false;
  }

  removeAlbum(id: string): boolean {
    const index = favorites.albums.indexOf(id);
    if (index !== -1) {
      favorites.albums.splice(index, 1);
      return true;
    }
    return false;
  }

  addArtist(id: string): boolean {
    if (this.artistService.findOne(id)) {
      favorites.artists.push(id);
      return true;
    }
    return false;
  }

  removeArtist(id: string): boolean {
    const index = favorites.artists.indexOf(id);
    if (index !== -1) {
      favorites.artists.splice(index, 1);
      return true;
    }
    return false;
  }
}
