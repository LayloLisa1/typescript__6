import { Track } from '../interfaces/track.interface';
import { v4 as uuidv4 } from 'uuid';

let tracks: Track[] = [];

export class TrackService {
  findAll(): Track[] {
    return tracks;
  }

  findOne(id: string): Track | undefined {
    return tracks.find(track => track.id === id);
  }

  create(name: string, artistId: string | null, albumId: string | null, duration: number): Track {
    const newTrack: Track = {
      id: uuidv4(),
      name,
      artistId,
      albumId,
      duration,
    };
    tracks.push(newTrack);
    return newTrack;
  }

  update(id: string, name: string, artistId: string | null, albumId: string | null, duration: number): Track | undefined {
    const track = this.findOne(id);
    if (track) {
      track.name = name;
      track.artistId = artistId;
      track.albumId = albumId;
      track.duration = duration;
      return track;
    }
    return undefined;
  }

  delete(id: string): boolean {
    const trackIndex = tracks.findIndex(track => track.id === id);
    if (trackIndex !== -1) {
      tracks.splice(trackIndex, 1);
      return true;
    }
    return false;
  }
}
