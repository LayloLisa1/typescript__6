import { User } from '../interfaces/user_interface';
import { v4 as uuidv4 } from 'uuid';

let users: User[] = [];

export class UserService {
  findAll(): User[] {
    return users;
  }

  findOne(id: string): User | undefined {
    return users.find(user => user.id === id);
  }

  create(login: string, password: string): User {
    const newUser: User = {
      id: uuidv4(),
      login,
      password,
      version: 1,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    users.push(newUser);
    return newUser;
  }

  updatePassword(id: string, oldPassword: string, newPassword: string): User | undefined {
    const user = this.findOne(id);
    if (!user || user.password !== oldPassword) return undefined;
    user.password = newPassword;
    user.version++;
    user.updatedAt = Date.now();
    return user;
  }

  delete(id: string): boolean {
    const userIndex = users.findIndex(user => user.id === id);
    if (userIndex === -1) return false;
    users.splice(userIndex, 1);
    return true;
  }
}
