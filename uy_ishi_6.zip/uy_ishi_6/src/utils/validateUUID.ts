import { validate } from 'uuid';

export const validateUUID = (uuid: string): boolean => validate(uuid);
